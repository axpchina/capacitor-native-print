// Modified by Robust Homes: private namespace and content-free diagnostics. See android/vendor/README.md.
/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.pdmodel.font;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.fontbox.cmap.CMap;
import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.fontbox.cmap.CMapParser;

/**
 * CMap resource loader and cache.
 */
final class CMapManager
{
    private static final Map<String, CMap> CMAP_CACHE = new ConcurrentHashMap<String, CMap>();

    private CMapManager()
    {
    }

    /**
     * Fetches the predefined CMap from disk (or cache).
     *
     * @param cMapName CMap name
     * @return The predefined CMap, never null.
     * @throws IOException
     */
    public static CMap getPredefinedCMap(String cMapName) throws IOException
    {
        CMap cmap = CMAP_CACHE.get(cMapName);
        if (cmap != null)
        {
            return cmap;
        }

        CMap targetCmap = new CMapParser().parsePredefined(cMapName);

        // limit the cache to predefined CMaps
        CMAP_CACHE.put(targetCmap.getName(), targetCmap);
        return targetCmap;
    }

    /**
     * Parse the given CMap.
     *
     * @param cMapStream the CMap to be read
     * @return the parsed CMap
     */
    public static CMap parseCMap(InputStream cMapStream) throws IOException
    {
        CMap targetCmap = null;
        if (cMapStream != null)
        {
            // parse CMap using strict mode
            targetCmap = new CMapParser(true).parse(cMapStream);
        }
        return targetCmap;
    }
}
