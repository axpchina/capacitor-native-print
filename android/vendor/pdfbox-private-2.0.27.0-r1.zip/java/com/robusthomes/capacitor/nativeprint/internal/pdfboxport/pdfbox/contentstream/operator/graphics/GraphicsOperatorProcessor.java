// Modified by Robust Homes: private namespace and content-free diagnostics. See android/vendor/README.md.
/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.contentstream.operator.graphics;

import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.contentstream.PDFGraphicsStreamEngine;
import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.contentstream.PDFStreamEngine;
import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.contentstream.operator.OperatorProcessor;

/**
 * Base class for graphics operators.
 *
 * @author John Hewson
 */
public abstract class GraphicsOperatorProcessor extends OperatorProcessor
{
    /** The processing context. */
    protected PDFGraphicsStreamEngine context;

    @Override
    public void setContext(PDFStreamEngine context)
    {
        super.setContext(context);
        this.context = (PDFGraphicsStreamEngine)context;
    }
}
