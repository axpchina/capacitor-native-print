// Modified by Robust Homes: private namespace and content-free diagnostics. See android/vendor/README.md.
/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.pdmodel.fdf;



import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.cos.COSArray;
import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.cos.COSBoolean;
import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.cos.COSDictionary;
import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.cos.COSName;
import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.cos.COSNumber;
import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.cos.COSStream;
import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.io.IOUtils;
import com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.util.Hex;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * This represents a Stamp FDF annotation.
 *
 * @author Ben Litchfield
 * @author Andrew Hung
 */
public class FDFAnnotationStamp extends FDFAnnotation
{
    /**
     * COS Model value for SubType entry.
     */
    public static final String SUBTYPE = "Stamp";

    /**
     * Default constructor.
     */
    public FDFAnnotationStamp()
    {
        annot.setName(COSName.SUBTYPE, SUBTYPE);
    }

    /**
     * Constructor.
     *
     * @param a An existing FDF Annotation.
     */
    public FDFAnnotationStamp(COSDictionary a)
    {
        super(a);
    }

    /**
     * Constructor.
     *
     * @param element An XFDF element.
     *
     * @throws IOException If there is an error extracting information from the element.
     */
    public FDFAnnotationStamp(Element element) throws IOException
    {
        super(element);
        annot.setName(COSName.SUBTYPE, SUBTYPE);

        // PDFBOX-4437: Initialize the Stamp appearance from the XFDF
        // https://www.immagic.com/eLibrary/ARCHIVES/TECH/ADOBE/A070914X.pdf
        // appearance is only defined for stamps
        XPath xpath = XPathFactory.newInstance().newXPath();

        // Set the Appearance to the annotation
        ;
        String base64EncodedAppearance;
        try
        {
            base64EncodedAppearance = xpath.evaluate("appearance", element);
        }
        catch (XPathExpressionException e)
        {
            // should not happen
            com.robusthomes.capacitor.nativeprint.PdfDiagnostics.warning();
            return;
        }
        byte[] decodedAppearanceXML;
        try
        {
            decodedAppearanceXML = Hex.decodeBase64(base64EncodedAppearance);
        }
        catch (IllegalArgumentException ex)
        {
            com.robusthomes.capacitor.nativeprint.PdfDiagnostics.warning();
            return;
        }
        if (base64EncodedAppearance != null && !base64EncodedAppearance.isEmpty())
        {
            ;

            Document stampAppearance = com.robusthomes.capacitor.nativeprint.internal.pdfboxport.pdfbox.util.XMLUtil
                .parse(new ByteArrayInputStream(decodedAppearanceXML));

            Element appearanceEl = stampAppearance.getDocumentElement();

            // Is the root node have tag as DICT, error otherwise
            if (!"dict".equalsIgnoreCase(appearanceEl.getNodeName()))
            {
                throw new IOException("Error while reading stamp document, "
                    + "root should be 'dict' and not '" + appearanceEl.getNodeName() + "'");
            }
            ;
            annot.setItem(COSName.AP, parseStampAnnotationAppearanceXML(appearanceEl));
        }
    }

    /**
     * This will create an Appearance dictionary from an appearance XML element.
     *
     * @param appearanceXML The XML element that contains the appearance data.
     */
    private COSDictionary parseStampAnnotationAppearanceXML(Element appearanceXML) throws IOException
    {
        COSDictionary dictionary = new COSDictionary();
        // the N entry is required.
        dictionary.setItem(COSName.N, new COSStream());
        ;

        NodeList nodeList = appearanceXML.getChildNodes();
        String parentAttrKey = appearanceXML.getAttribute("KEY");
        ;

        // Currently only handles Appearance dictionary (AP key on the root)
        if (!"AP".equals(appearanceXML.getAttribute("KEY")))
        {
            com.robusthomes.capacitor.nativeprint.PdfDiagnostics.warning();
            return dictionary;
        }
        for (int i = 0; i < nodeList.getLength(); i++)
        {
            Node node = nodeList.item(i);
            if (node instanceof Element)
            {
                Element child = (Element) node;
                if ("STREAM".equalsIgnoreCase(child.getTagName()))
                {
                    ;
                    dictionary.setItem(child.getAttribute("KEY"), parseStreamElement(child));
                    ;
                }
                else
                {
                    com.robusthomes.capacitor.nativeprint.PdfDiagnostics.warning();
                }
            }
        }
        return dictionary;
    }

    private COSStream parseStreamElement(Element streamEl) throws IOException
    {
        ;
        COSStream stream = new COSStream();

        NodeList nodeList = streamEl.getChildNodes();
        String parentAttrKey = streamEl.getAttribute("KEY");

        for (int i = 0; i < nodeList.getLength(); i++)
        {
            Node node = nodeList.item(i);
            if (node instanceof Element)
            {
                Element child = (Element) node;
                String childAttrKey = child.getAttribute("KEY");
                String childAttrVal = child.getAttribute("VAL");
                ;
                if ("INT".equalsIgnoreCase(child.getTagName()))
                {
                    if (!"Length".equals(childAttrKey))
                    {
                        stream.setInt(COSName.getPDFName(childAttrKey), Integer.parseInt(childAttrVal));
                        ;
                    }
                }
                else if ("FIXED".equalsIgnoreCase(child.getTagName()))
                {
                    stream.setFloat(COSName.getPDFName(childAttrKey), Float.parseFloat(childAttrVal));
                    ;
                }
                else if ("NAME".equalsIgnoreCase(child.getTagName()))
                {
                    stream.setName(COSName.getPDFName(childAttrKey), childAttrVal);
                    ;
                }
                else if ("BOOL".equalsIgnoreCase(child.getTagName()))
                {
                    stream.setBoolean(COSName.getPDFName(childAttrKey), Boolean.parseBoolean(childAttrVal));
                    ;
                }
                else if ("ARRAY".equalsIgnoreCase(child.getTagName()))
                {
                    stream.setItem(COSName.getPDFName(childAttrKey), parseArrayElement(child));
                    ;
                }
                else if ("DICT".equalsIgnoreCase(child.getTagName()))
                {
                    stream.setItem(COSName.getPDFName(childAttrKey), parseDictElement(child));
                    ;
                }
                else if ("STREAM".equalsIgnoreCase(child.getTagName()))
                {
                    stream.setItem(COSName.getPDFName(childAttrKey), parseStreamElement(child));
                    ;
                }
                else if ("DATA".equalsIgnoreCase(child.getTagName()))
                {
                    ;
                    if ("HEX".equals(child.getAttribute("ENCODING")))
                    {
                        OutputStream os = null;
                        try
                        {
                            os = stream.createRawOutputStream();
                            os.write(Hex.decodeHex(child.getTextContent()));
                            ;
                        }
                        finally
                        {
                            IOUtils.closeQuietly(os);
                        }
                    }
                    else if ("ASCII".equals(child.getAttribute("ENCODING")))
                    {
                        OutputStream os = null;
                        try
                        {
                            os = stream.createOutputStream();
                            // not sure about charset
                            os.write(child.getTextContent().getBytes());
                            ;
                        }
                        finally
                        {
                            IOUtils.closeQuietly(os);
                        }
                    }
                    else
                    {
                        com.robusthomes.capacitor.nativeprint.PdfDiagnostics.warning();
                    }
                }
                else
                {
                    com.robusthomes.capacitor.nativeprint.PdfDiagnostics.warning();
                }
            }
        }

        return stream;
    }

    private COSArray parseArrayElement(Element arrayEl) throws IOException
    {
        ;
        COSArray array = new COSArray();

        NodeList nodeList = arrayEl.getChildNodes();
        String parentAttrKey = arrayEl.getAttribute("KEY");

        if ("BBox".equals(parentAttrKey) && nodeList.getLength() < 4)
        {
            throw new IOException("BBox does not have enough coordinates, only has: " +
                nodeList.getLength());
        }
        else if ("Matrix".equals(parentAttrKey) && nodeList.getLength() < 6)
        {
            throw new IOException("Matrix does not have enough coordinates, only has: " +
                nodeList.getLength());
        }

        for (int i = 0; i < nodeList.getLength(); i++)
        {
            Node node = nodeList.item(i);
            if (node instanceof Element)
            {
                Element child = (Element) node;
                String childAttrKey = child.getAttribute("KEY");
                String childAttrVal = child.getAttribute("VAL");
                ;
                if ("INT".equalsIgnoreCase(child.getTagName()) || "FIXED".equalsIgnoreCase(child.getTagName()))
                {
                    ;
                    array.add(COSNumber.get(childAttrVal));
                }
                else if ("NAME".equalsIgnoreCase(child.getTagName()))
                {
                    ;
                    array.add(COSName.getPDFName(childAttrVal));
                }
                else if ("BOOL".equalsIgnoreCase(child.getTagName()))
                {
                    ;
                    array.add(COSBoolean.getBoolean(Boolean.parseBoolean(childAttrVal)));
                }
                else if ("DICT".equalsIgnoreCase(child.getTagName()))
                {
                    ;
                    array.add(parseDictElement(child));
                }
                else if ("STREAM".equalsIgnoreCase(child.getTagName()))
                {
                    ;
                    array.add(parseStreamElement(child));
                }
                else if ("ARRAY".equalsIgnoreCase(child.getTagName()))
                {
                    ;
                    array.add(parseArrayElement(child));
                }
                else
                {
                    com.robusthomes.capacitor.nativeprint.PdfDiagnostics.warning();
                }
            }
        }

        return array;
    }

    private COSDictionary parseDictElement(Element dictEl) throws IOException
    {
        ;
        COSDictionary dict = new COSDictionary();

        NodeList nodeList = dictEl.getChildNodes();
        String parentAttrKey = dictEl.getAttribute("KEY");

        for (int i = 0; i < nodeList.getLength(); i++)
        {
            Node node = nodeList.item(i);
            if (node instanceof Element)
            {
                Element child = (Element) node;
                String childAttrKey = child.getAttribute("KEY");
                String childAttrVal = child.getAttribute("VAL");

                if ("DICT".equals(child.getTagName()))
                {
                    ;
                    dict.setItem(COSName.getPDFName(childAttrKey), parseDictElement(child));
                    ;
                }
                else if ("STREAM".equals(child.getTagName()))
                {
                    ;
                    dict.setItem(COSName.getPDFName(childAttrKey), parseStreamElement(child));
                }
                else if ("NAME".equals(child.getTagName()))
                {
                    ;
                    dict.setName(COSName.getPDFName(childAttrKey), childAttrVal);
                    ;
                }
                else if ("INT".equalsIgnoreCase(child.getTagName()))
                {
                    dict.setInt(COSName.getPDFName(childAttrKey), Integer.parseInt(childAttrVal));
                    ;
                }
                else if ("FIXED".equalsIgnoreCase(child.getTagName()))
                {
                    dict.setFloat(COSName.getPDFName(childAttrKey), Float.parseFloat(childAttrVal));
                    ;
                }
                else if ("BOOL".equalsIgnoreCase(child.getTagName()))
                {
                    dict.setBoolean(COSName.getPDFName(childAttrKey), Boolean.parseBoolean(childAttrVal));
                    ;
                }
                else if ("ARRAY".equalsIgnoreCase(child.getTagName()))
                {
                    dict.setItem(COSName.getPDFName(childAttrKey), parseArrayElement(child));
                    ;
                }
                else
                {
                    com.robusthomes.capacitor.nativeprint.PdfDiagnostics.warning();
                }
            }
        }

        return dict;
    }
}
